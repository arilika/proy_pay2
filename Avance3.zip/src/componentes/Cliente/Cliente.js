import React from 'react';
import './Cliente.css';

class Cliente extends React.Component {
    constructor(props) {
        super(props);
        this.nombre = {};
        this.apellido = {};
        this.cuenta = {};

    }


}
export default Cliente;
