import React from 'react';
import './Footer.css';

function Footer(props) {
    return (

        <div className="Footer">
            <h1>{props.slogan}:</h1>

        </div>


    );
}
export default Footer;