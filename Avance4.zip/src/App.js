import React from 'react';
import logo from './logo.png';
import './App.css';
import Article from './Article/Article';
import FechaActual from './componentes/FechaActual/FechaActual';
import Event from './componentes/Event/Event';
import Bienvenido from './componentes/Bienvenido/Bienvenido';
import Autenticacion from './componentes/Autenticacion/Autenticacion';
import ListaDatos from './componentes/ListaDatos/ListaDatos';

const slogan = "Easy, Fast & Safe";
//var nombre = "Ariela"
const movimientos = ["28/10/2018", "28/11/2019", "28/12/2019", "28/01/2020", "28/02/2020", "28/03/2020"];
const montos = ["1000", "1400", "2000", "900", "970", "300"];
const nombre = "Ariela";
/*function Bienvenida(props) {
  return <h3>Bienvenida {props.nombre}</h3>
}*/

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div className="logo">
          <img src={logo} className="App-logo" alt="logo" />
          <div className="slogan"><h2>{slogan}</h2></div>
        </div>
        <div className="bienvenida">
          <Autenticacion nombre={nombre} />
        </div>
      </header>
      <div className="container">
        <h1>Ultimos Movimientos</h1>
        <ListaDatos datos={movimientos} />
      </div>

    </div>
  );
}

export default App;
