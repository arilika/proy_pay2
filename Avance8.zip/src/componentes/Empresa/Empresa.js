import React from 'react';
import './Empresa.css';

class Empresa extends React.Component {
    constructor(props) {
        super(props);
        this.nombreEmpresa = {};

    }


}
export default Empresa;
